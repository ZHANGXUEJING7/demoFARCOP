% Written by Xuejing Zhang
% Email: xjzhang7@163.com
% Date: 19 Sep, 2023
% reference:
% Flexible Array Response Control via Oblique Projection

% Description: In this demonstration, we apply the FARCOP algorithm to synthesize a
% nonuniform sidelobe pattern for a large ULA. The initial weight vector of FARCOP
% is taken as the Chebyshev weight.

clear;
clc;
close all;

lambda=1;                                                         %wavelength
ele_num=100;                                                    %number of element
sensor_pos=[0:(ele_num-1)]'*(lambda/2);            %sensor locations

beam_axis_angle=60;                                         %angle of beam axis
scan_diff=0.1;                                                     %space of scan angle
seek_theta=[-90:scan_diff:90];                             %scan sector
seek_num=length(seek_theta);                            %total number of scan number
center_index=round((beam_axis_angle-(seek_theta(1)))/scan_diff)+1;                  %index of beam axis

steer_vector_all=exp(1j*2*pi*sensor_pos*sin(seek_theta/180*pi)/lambda);            %all steering vectors
steering_vec_beam_axis=steer_vector_all(:,center_index);                                     %steering vector of beam axis

main_left_angle=beam_axis_angle-1;                  %an angle on the left side of beam axis (roughly given)
main_left_index=round((main_left_angle-(seek_theta(1)))/scan_diff)+1;
main_right_angle=beam_axis_angle+1;               %an angle on the right side of beam axis (roughly given)
main_right_index=round((main_right_angle-(seek_theta(1)))/scan_diff)+1;

pattern_desired=zeros(1,seek_num);                    %desired pattern
for reg_desired=1:seek_num
    cur_angle=seek_theta(reg_desired);
    if(cur_angle>main_left_angle)&&(cur_angle<main_right_angle)
        pattern_desired(reg_desired)=0/0;               %not displayed
    else
        if(cur_angle<-20)
            pattern_desired(reg_desired)=-35;
        elseif(cur_angle<30)
            pattern_desired(reg_desired)=-45;           %nonuniform sidelobe level
        else
            pattern_desired(reg_desired)=-35;
        end
    end
end

resp_qui=abs(steering_vec_beam_axis'*steer_vector_all);
pattern_qui=20*log10(resp_qui./max(resp_qui(center_index))+1.0e-6);      %quiescent pattern

initial_sidelobe=-35;
cheby_initial=steering_vec_beam_axis.*chebwin(ele_num,-initial_sidelobe);     %the initial chebyshev weight
resp_cheby=abs(cheby_initial'*steer_vector_all);
pattern_cheby=20*log10(resp_cheby./max(resp_cheby(center_index))+1.0e-6);      %corresponding pattern

% several parameters about figure displayed
x_min=seek_theta(1);
x_max=seek_theta(end);
y_min=-50;
y_max=10;
f_size=12;

% display the quiescent pattern and Chebyshev pattern
figure;
plot(seek_theta,pattern_qui,'color','b','LineStyle','-.','LineWidth',1.5);hold on;
plot(seek_theta,pattern_cheby,'color','m','LineStyle','-','LineWidth',1);hold on;
plot(seek_theta,pattern_desired,'k--','LineWidth',1);hold off;
xlabel('Angle of Arrival (degrees)'); ylabel('Beampattern (dB)');
line([beam_axis_angle,beam_axis_angle],[-70,10],'linewidth',1.3,'color','k','LineStyle','--');
ylim([y_min y_max]);
xlim([x_min,x_max]);
legend('quiescent pattern','Chebyshev pattern','desired pattern');
set(gca,'fontsize',f_size);

w_pre=cheby_initial;                                    %set the initial weight of FACTOR as Chebyshev weight
last_pattern=pattern_cheby;                        %set the initial pattern as the Chebyshev pattern

loop_num=12;                                             %number of iterations
controlled_num_per_step=30;                     %number of controlled points per step
tic
for reg=1:loop_num
    deviation_cur=[];
    peak_angle_all=[];
    peak_db_all=[];
    for sidelobe_index=2:(seek_num-1)
        if(sidelobe_index>main_left_index)&&(sidelobe_index<main_right_index)
            continue;
        else
            if(last_pattern(sidelobe_index-1)<last_pattern(sidelobe_index))&&...
                    (last_pattern(sidelobe_index+1)<last_pattern(sidelobe_index))           %find the peak angle in sidelobe region
                deviation_cur=[deviation_cur abs(last_pattern(sidelobe_index)-pattern_desired(sidelobe_index))]; %deviation value
                peak_angle_all=[peak_angle_all seek_theta(sidelobe_index)];                 %store all peak angles
                peak_db_all=[peak_db_all pattern_desired(sidelobe_index)];                  %desired levels at the peak angles
            end
        end
    end
    
    [diff_cur_modi,ordd]=sort(deviation_cur,'descend');
    peak_angle_all=peak_angle_all(ordd(1:controlled_num_per_step));  %find out several peak angles with large deviations
    peak_db_all=peak_db_all(ordd(1:controlled_num_per_step));
    steering_vec_of_control=exp(1j*2*pi*sensor_pos*sin(peak_angle_all/180*pi)/lambda);
    
    rou_v_all=10.^(peak_db_all./10);
    
    
    [w_cur] = FACTOR_by_r(w_pre,steering_vec_beam_axis,steering_vec_of_control,...
        controlled_num_per_step,rou_v_all,ele_num);                         %parameter vector set as r
    
    resp_cur=abs(w_cur'*steer_vector_all);
    pattern_cur=20*log10(resp_cur./max(resp_cur(center_index))+1.0e-6);
    
    %     uncomment the following lines to see the intermediate results
    
    %         figure;
    %         plot(seek_theta,last_pattern,'color','g','LineStyle','-.','LineWidth',1.5);hold on;
    %         plot(seek_theta,pattern_cur,'LineWidth',1.5,'color','r','LineStyle','-');hold on;
    %         plot(seek_theta,pattern_desired,'k--','LineWidth',1);hold off;
    %         for plot_loop=1:length(peak_db_all)
    %             j_an=peak_db_all(plot_loop);
    %             line([peak_angle_all(plot_loop),peak_angle_all(plot_loop)],[-70,10],'linewidth',1.3,'color','m','LineStyle','--');
    %         end
    %         xlabel('Angle of Arrival (degrees)'); ylabel('Beampattern (dB)');
    %         legend('previous pattern','current pattern');
    %         line([beam_axis_angle,beam_axis_angle],[-70,10],'linewidth',1.3,'color','k','LineStyle','--');
    %         ylim([-50 10]);
    %         xlim([-90,90]);
    %         set(gca,'fontsize',f_size);
    
    last_pattern=pattern_cur;
    w_pre=w_cur;
end
toc
w_FACTOR=w_cur;

%display the final result
figure;
plot(seek_theta,pattern_cheby,'color','g','LineStyle','-.','LineWidth',1.5);hold on;
plot(seek_theta,pattern_cur,'LineWidth',1.5,'color','r','LineStyle','-');hold on;
plot(seek_theta,pattern_desired,'k--','LineWidth',1);hold off;
xlabel('Angle of Arrival (degrees)'); ylabel('Beampattern (dB)');
line([beam_axis_angle,beam_axis_angle],[-70,10],'linewidth',1.3,'color','k','LineStyle','--');
ylim([-50 10]);
xlim([-90,90]);
legend('initial pattern','synthesized pattern');
set(gca,'fontsize',f_size);


