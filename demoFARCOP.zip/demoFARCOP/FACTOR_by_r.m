function [ w_final] = FACTOR_by_r(w0,st_0,j_st_all,jam_num,rou_v_all,N)
P_other=st_0/(st_0'*st_0)*st_0';
P_other_bar=eye(N)-P_other;
E_cur=j_st_all/(j_st_all'*P_other_bar*j_st_all)*j_st_all'*P_other_bar;
P_all_bar=eye(N)-E_cur;
w0_bar=P_all_bar'*w0;
w_cc_all=zeros(N,jam_num);
r_direct_all=zeros(jam_num,1);
for point_reg=1:jam_num
    st_cur=j_st_all(:,point_reg);
    j_st_all_reg=j_st_all;
    j_st_all_reg(:,point_reg)=[];
    st_other_all=[st_0 j_st_all_reg];
    P_other=st_other_all/(st_other_all'*st_other_all)*st_other_all';
    P_other_bar=eye(N)-P_other;  
    
    E_cur=st_cur/(st_cur'*P_other_bar*st_cur)*st_cur'*P_other_bar;
    w_cc=E_cur'*w0;
    w_cc_all(:,point_reg)=w_cc;
    r_direct_all(point_reg)=sqrt(rou_v_all(point_reg))*abs(w0'*st_0)/abs(w0'*st_cur);
end
r_modi_all=[1;r_direct_all];
w_final=[w0_bar w_cc_all]*r_modi_all;
end

